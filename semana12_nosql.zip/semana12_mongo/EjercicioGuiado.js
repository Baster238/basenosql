
// 1. CONFIGURACIÓN DE USUARIO ADMINISTRADOR PRINCIPAL
// Nos posicionamos en la base de datos "admin"
use("admin");
db.createUser({
  user: "admin",
  pwd: "Admin123*",
  roles: [ { role: "root", db: "admin" } ]
});


// 2. CONFIGURACIÓN DE LA BASE DE DATOS: gestion_academica
// Cambiamos el contexto a la base académica
use("gestion_academica");
db.createUser({
  user: "docente",
  pwd: "Docente123*",
  roles: [ { role: "readWrite", db: "gestion_academica" } ]
});

db.createUser({
  user: "consulta",
  pwd: "Consulta123*",
  roles: [ { role: "read", db: "gestion_academica" } ]
});

// 3. SECCIÓN:
// Coordinador con permisos de dbAdmin
db.createUser({
  user: "coordinador",
  pwd: "Coordinador123*", 
  roles: [ { role: "dbAdmin", db: "gestion_academica" } ]
});

// Auditor con permisos únicamente de lectura
db.createUser({
  user: "auditor",
  pwd: "Auditor123*",
  roles: [ { role: "read", db: "gestion_academica" } ]
});

// Creación de un Rol Personalizado (Solo permite insertar datos en las colecciones)
db.createRole({
  role: "soloInsertar",
  privileges: [
    { resource: { db: "gestion_academica", collection: "" }, actions: [ "insert" ] }
  ],
  roles: []
});

// Asignando el nuevo Rol Personalizado a un usuario nuevo
db.createUser({
  user: "digitador",
  pwd: "Digitador123*",
  roles: [ { role: "write", db: "gestion_academica" } ]
});

// 4. CONSULTAS DE DIAGNÓSTICO Y MANTENIMIENTO (INVESTIGACIÓN)

// Ver todos los usuarios creados en la base de datos actual
db.getUsers();

